/**
 * InductsForTheDay
 */
import React, { Component } from 'react';

//json
import json from '../../assets/data/JSON/UnitSorterMainDashboard/inductsForTheDayJson';

// api
import api from 'Api';
import CountUp from 'react-countup';
//chart
import TinyAreaChart from 'Components/Charts/TinyAreaChart';
//chart config
import ChartConfig from 'Constants/chart-config';

// helpers
import { hexToRgbA } from 'Helpers/helpers';
import {baseURL} from '../../services/Config.js';
import CircularProgressbar from 'react-circular-progressbar';
//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';

import NumberClass from 'Util/NumberClass';
var dateFormat = require('dateformat'); 

class InductsForTheDay extends Component {

	state = {
			data: [],
			label: null,
			graphData: null,
			currentValue: 0
	}

	/*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.getRecentOrders();
	}

	//Comparing props and triggering refresh 
	componentDidUpdate(prevProps) {
		// Typical usage (don't forget to compare props):
		if (this.props.currentTime !== prevProps.currentTime) {
			this.getRecentOrders();
		}
	}

	// recent orders
	getRecentOrders() {
		let currentTemp = 0;
		let query = `query GetInductsForLastHour($key: String!, $startTime: String!) {
						getInductsForLastHour(key: $key, startTime: $startTime) { duration measure condition totalInducts }
					}`;
		let key = "USSStatistics";
		let currentTime = dateFormat(new Date(), "mm-dd-yyyy H:MM");
		console.log("============================================")
		console.log(currentTime);
		console.log("============================================")
		let startTime = dateFormat(new Date(), "mm-dd-yyyy H:MM");
		//let startTime = '02-18-2019 15:59';
		//let query = '{getInductsForLastHour(key: "USSStatistics",startTime:"02-18-2019 15:59") { duration measure condition totalInducts }}';
		fetch('http://localhost:9090/graphql', {
			method: 'POST',
			headers: {
			'Content-Type': 'application/json',
			'Accept': 'application/json',
			},
			body: JSON.stringify({
			query,
			variables: { key, startTime }
			})
		})
		.then(r => r.json())
		.then(data => { currentTemp = data.data.getInductsForLastHour.totalInducts;
						api.get(baseURL+'inductsfortheday/'+ localStorage.getItem("user_id") +this.props.sorterRoute)
		 .then(res => {
			    let label = res.data.inductsForTheDayList.map(list => list.currentDt);
			    let graphData = res.data.inductsForTheDayList.map(list => list.curr_value);
			    
			    this.setState({ data: res.data,
		        				label: label,
								currentValue: currentTemp,
		        				graphData: graphData,
								isLoading:false
					        });
		   }).catch(function (error) {
				console.log(error);
		  });
						return data; 
					})
		.catch((error) => {
			console.log(error);
		});
	}

	render() {
	if(this.state.isLoading){
			return <div>Loading...</div>;
		} else {
		const { recentOrders } = this.state;
		const percentage  = this.state.data.percentValue

		return (
				<RctCollapsibleCard
				colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
				heading={json.inductfortheDay.title}
				fullBlock
				>
					<div className="clearfix">
	                <div className="col-md-12 col-xl-12 col-sm-12 col-ls-12 float-left">
	                    <div className="d-flex">
	                        <div className="col-md-4 col-xl-4 col-sm-4 col-ls-4">
	                        	<CircularProgressbar percentage={this.state.data.percentValue}
	                        						 text={`${this.state.data.percentValue}%`
													 }
	                        						 backgroundPadding={10}
													
	                        						 styles={{ path: { stroke: json.inductfortheDay.guageComponent.guageBGColor, strokeLinecap: 'butt' },
	                        							 	   text: { fill: '#121212', fontSize: '25px', textAnchor: "middle", dominantBaseline: "middle"},
	                        							 	   trail: { stroke: '#d7d7d7' },
	                        							 	   background: { fill: '#c3c3c3' }
															   
	                        						 }}
	                        	/>
	                        </div>
	                        <div className="col-md-8 col-xl-8 col-sm-8 col-ls-8">
	                            <div className="col-md-12 col-xl-12 col-sm-12 col-ls-12 text-center">
	                                <span className="counter-point">
										<strong>&nbsp; <NumberClass  number={this.state.currentValue} />  / &nbsp;
										<span style={{color: json.inductfortheDay.descComponent.fontColor}}><NumberClass  number={json.inductfortheDay.descComponent.goal} /></span></strong>
	                                    {/*<IntlMessages id="widgets.weekly" /> / <IntlMessages id="widgets.monthly" />*/}
	                                </span>
	                            </div>
	                            <div className="col-md-12 col-xl-12 col-sm-12 col-ls-12">
								<div className="lastdays-text">{json.inductfortheDay.descComponent.chartLabel}</div>
	                                <TinyAreaChart
	                                  
	                                    chartdata={this.state.graphData}
	                                    labels={this.state.label}
	                                    backgroundColor={hexToRgbA(ChartConfig.color.primary, 0.1)}
	                                    borderColor={json.inductfortheDay.lineComponent.graphBGColor}
										lineTension="0"
	                                    height={130}
										fixedHeader={true}
	                                    gradient
	                                />
	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </RctCollapsibleCard>
		);
		}
	}
}

export default InductsForTheDay;
