/**
 * InductsForTheDay
 */
import React, { Component } from 'react';

//json
import json from '../../assets/data/JSON/UnitSorterMainDashboard/inductsForLastHourJson';

// api
import api from 'Api';
import CountUp from 'react-countup';
//chart
import TinyAreaChart from 'Components/Charts/TinyAreaChart';
//chart config
import ChartConfig from 'Constants/chart-config';

// helpers
import { hexToRgbA } from 'Helpers/helpers';
import {baseURL} from '../../services/Config.js';
import CircularProgressbar from 'react-circular-progressbar';
//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';
import ReactSpeedometer from "react-d3-speedometer";
import GuageD3 from "./D3Speedometer";
import NumberClass from 'Util/NumberClass';
var dateFormat = require('dateformat');
class InductsForTheLastHour extends Component {

	state = {
			data: {},
			label: [],
			graphData: [],
			isLoading:true,
			currentValue: 0
	}

	/*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.getRecentOrders();
	}

	//Comparing props and triggering refresh
	componentDidUpdate(prevProps) {
		// Typical usage (don't forget to compare props):
		if (this.props.currentTime !== prevProps.currentTime) {
			this.getRecentOrders();
		}
	}

	// recent orders
	getRecentOrders() {
	let query = `query GetInductsForLastHour($key: String!, $startTime: String!) {
						getInductsForLastHour(key: $key, startTime: $startTime) { duration measure condition totalInducts }
					}`;
		let key = "USSStatistics";
		let currentTime = dateFormat(new Date(), "mm-dd-yyyy H:MM");
		console.log("============================================")
		console.log(currentTime);
		console.log("============================================")
		let startTime = dateFormat(new Date(), "mm-dd-yyyy H:MM");
		//let query = '{getInductsForLastHour(key: "USSStatistics",startTime:"02-04-2019 14:40") { duration measure condition totalInducts }}';
		fetch('http://localhost:9090/graphql', {
			method: 'POST',
			headers: {
			'Content-Type': 'application/json',
			'Accept': 'application/json',
			},
			body: JSON.stringify({
			query,
			variables: { key, startTime }
			})
		})
		.then(r => r.json())
		.then(data => this.setState({currentValue: data.data.getInductsForLastHour.totalInducts}))
		.catch((error) => {
			console.log(error);
		});
		api.get(baseURL+'inductsforlasthour/'+ localStorage.getItem("user_id") +this.props.sorterRoute)
		 .then(res => {
			    let label = res.data.inductsForLastHour.map(list => list.currentHour);
			    let graphData = res.data.inductsForLastHour.map(list => list.currValue);
			    
			    this.setState({ data: res.data,
		        				label: label,
		        				graphData: graphData,
					        	isLoading:false}); })
			.catch(function (error) {
				console.log(error);
		  });
	}
	strokeColor = "";
	render() {
		if(this.state.isLoading){
			return <div>Loading...</div>;
		} else {
			const { recentOrders } = this.state;
			const percentage  = this.state.data.percentValue;
			
			// Set the color based on Percentage value 
			if(percentage < 30) {
				this.strokeColor = "#d0021b";
			} else if(percentage >= 30 && percentage <=80) {
				this.strokeColor = "#f8e71c";
			} else if(percentage > 80) {
				this.strokeColor = "#2ecc71";
			} 

			return (
					<RctCollapsibleCard
					colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
					heading={json.inductforlastHour.title}
					fullBlock
					>
					<div className="clearfix">
						<div className="col-md-12 col-xl-12 col-sm-12 col-ls-12 float-left">
							<div className="d-flex">
								<div className="col-md-4 col-xl-4 col-sm-4 col-ls-4">
							
								<GuageD3
									percent={percentage} // Current Percentage value 												   
									needleLength={60} // Needle Length Range from 0 - 100												   
									needleRadius={4} //Needle Radius Range from 0 - 10											   
									needleColor={"#464A4F"} //Needle Color can be hex vlaue or name ofcolor								   
									barWidth={10} //Bar Width Range from be 0 - 50									   
									width={120}				   
									height={120}						   
									textSize={"20px"} //Percentage Text Size
									sections = {[                               
										{ fill: '#d0021b', stroke: '#d0021b', sectionPercent: 30 }, 
										{ fill: '#f8e71c', stroke: '#f8e71c', sectionPercent: 50 },
										{ fill: '#2ecc71', stroke: '#2ecc71', sectionPercent: 20 }						   
									]} //Number sections and sectionwise color, percentage
							/>


								</div>
								<div className="col-md-8 col-xl-8 col-sm-8 col-ls-8">
									<div className="col-md-12 col-xl-12 col-sm-12 col-ls-12 text-center">
										<span className="counter-point">
											<strong>&nbsp; <NumberClass  number={this.state.currentValue} />  / &nbsp;
											<span style={{color: json.inductforlastHour.descComponent.fontColor}}><NumberClass  number={json.inductforlastHour.descComponent.goal} /></span></strong>
											{/*<IntlMessages id="widgets.weekly" /> / <IntlMessages id="widgets.monthly" />*/}
										</span>
									</div>
									<div className="col-md-12 col-xl-12 col-sm-12 col-ls-12">
									<div className="lastdays-text">{json.inductforlastHour.descComponent.chartLabel}</div>
										<TinyAreaChart
											chartdata={this.state.graphData}
											labels={this.state.label}
											backgroundColor={hexToRgbA(ChartConfig.color.primary, 0.1)}
											borderColor={json.inductforlastHour.lineComponent.graphBGColor}
											lineTension="0"
											height={130}
											gradient
											borderColor={this.strokeColor}
										/>
									</div>
								</div>
							</div>
						</div>
					</div>
				</RctCollapsibleCard>
			);
		}
	}
}

export default InductsForTheLastHour;
