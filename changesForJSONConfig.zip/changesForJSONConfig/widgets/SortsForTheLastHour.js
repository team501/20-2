/**
 * InductsForTheDay
 */
import React, { Component } from 'react';

//json
import json from '../../assets/data/JSON/UnitSorterMainDashboard/sortsForLastHourJson';

// api
import api from 'Api';
import CountUp from 'react-countup';
//chart
import TinyAreaChart from 'Components/Charts/TinyAreaChart';
//chart config
import ChartConfig from 'Constants/chart-config';

// helpers
import { hexToRgbA } from 'Helpers/helpers';
import {baseURL} from '../../services/Config.js';
import CircularProgressbar from 'react-circular-progressbar';
//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';
import ReactSpeedometer from "react-d3-speedometer";
import NumberClass from 'Util/NumberClass';
 
class SortsForTheLastHour extends Component {

	state = {
			data: {},
			label: [],
			graphData: [],
			isLoading:true
	}

	/*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.getRecentOrders();
	}

	//Comparing props and triggering refresh 
	componentDidUpdate(prevProps) {
		// Typical usage (don't forget to compare props):
		if (this.props.currentTime !== prevProps.currentTime) {
			this.getRecentOrders();
		}
	}

	// recent orders
	getRecentOrders() {
		api.get(baseURL+'inductsforlasthour/'+ localStorage.getItem("user_id") +this.props.sorterRoute)
		 .then(res => {
			    
			    let label = res.data.inductsForLastHour.map(list => list.currentHour);
			    let graphData = res.data.inductsForLastHour.map(list => list.currValue);
			    
				this.setState({ data: res.data,
		        				label: label,
		        				graphData: graphData,
								isLoading:false
							});
		})
		.catch(function (error) {
			console.log(error);
		});
	}

	strokeColor = "";

	render() {

		if(this.state.isLoading){
			return <div>Loading...</div>;
		} else {
			const { recentOrders } = this.state;
			const percentage  = this.state.data.percentValue;
			// Set the color based on Percentage value 
			if(percentage < 30) {
				this.strokeColor = "#d0021b";
			} else if(percentage >= 30 && percentage < 80) {
				this.strokeColor = "#f8e71c";
			} else if(percentage >= 80) {
				this.strokeColor = "#2ecc71";
			}

			return (
					<RctCollapsibleCard
					colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
					heading={json.sortsforlastHour.title}
					fullBlock
					>
						<div className="clearfix">
						<div className="col-md-12 col-xl-12 col-sm-12 col-ls-12 float-left">
							<div className="d-flex">
								<div className="col-md-4 col-xl-4 col-sm-4 col-ls-4">
								<ReactSpeedometer
									//startColor={percentage < 30 ? "#d0021b" : (percentage >= 30 && percentage < 80) ? "#f8e71c" : percentage >= 80 ? "#2ecc71" : ""}
									segments={2} 
									width={135} 
									height={100} 
									ringWidth={10}
									minValue={0} 
									maxValue={100}
									value={this.state.data.percentValue}
									needleHeightRatio={0.5}
									currentValueText="${value} %"
								/>
								</div>
								<div className="col-md-8 col-xl-8 col-sm-8 col-ls-8">
									<div className="col-md-12 col-xl-12 col-sm-12 col-ls-12 text-center">
										<span className="counter-point">
											<strong>&nbsp; <NumberClass  number={this.state.data.currentValue} />  / &nbsp;
											<span style={{color: json.sortsforlastHour.descComponent.fontColor}}><NumberClass  number={json.sortsforlastHour.descComponent.goal} /></span></strong>
											{/*<IntlMessages id="widgets.weekly" /> / <IntlMessages id="widgets.monthly" />*/}
										</span>
									</div>
									<div className="col-md-12 col-xl-12 col-sm-12 col-ls-12">
									<div className="lastdays-text">{json.sortsforlastHour.descComponent.chartLabel}</div>
										<TinyAreaChart
											label="Visitors"
											chartdata={this.state.graphData}
											labels={this.state.label}
											backgroundColor={hexToRgbA(ChartConfig.color.primary, 0.1)}
											borderColor={json.sortsforlastHour.lineComponent.graphBGColor}
											lineTension="0"
											height={130}
											gradient
										/>
									</div>
								</div>
							</div>
						</div>
					</div>
				</RctCollapsibleCard>
			);
		}
	}
}

export default SortsForTheLastHour;
